from flask import Flask,render_template,request, redirect
import requests

app = Flask(__name__)

import routes







if __name__ == '__main__':
    app.run()
